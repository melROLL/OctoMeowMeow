#!/bin/bash

echo"This scripts install the requierement necessaries to build the image"

sudo apt update 
wait
sudo apt-get update 
wait
sudo apt-get install virtualbox -y
wait
sudo apt install vagrant git -y
wait
sudo apt upgrade -y
wait
./octowasp.sh box #
wait
./octowasp.sh assets #download all the assets 

echo "========================"
echo "OctoMeow is ready to run"
echo "========================"
