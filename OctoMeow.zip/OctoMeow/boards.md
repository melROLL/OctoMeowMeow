# Boards supported

## Banana PI M2 Zero

- Name: bpm2z
- Image bananapim2zero
